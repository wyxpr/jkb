# -*- coding: utf-8 -*-
"""
 Copyright © 2012 云智慧（北京）科技有限公司 <http://www.jiankongbao.com/>
 
 Permission is hereby granted, free of charge, to any person obtaining a copy of this software
 and associated documentation files (the "Software"), to deal in the Software without restriction,
 including without limitation the rights to use, copy, modify, merge, publish, distribute,
 sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:
 
 The above copyright notice and this permission notice shall be included in all copies or
 substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND 
 NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, 
 DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE. 
"""
"""
Jiankongbao traceroute plugin
sevn.huo@yunzhihui.com
"""

from lib import jkbLib
import traceback
import re
import subprocess
from p_class import plugins
import sys


class TracePlugin(plugins.plugin):

    def __init__(self,taskId,taskConf,taskType):
        plugins.plugin.__init__(self,taskId,taskConf,taskType)
        self.sys_type=jkbLib.UsePlatform()
        try:
            reload(sys)
            sys.setdefaultencoding('utf8')
        except Exception:
            pass
        

    
    def getAvg(self, totle,val, count ):
        if val==0:
            count[0]+=1
        else:
            totle.append(val)


    def getRespAvg(self, arr):
        totle=[]
        count=[0]
        ip=arr[1]
        
        try:
            a=arr[2].split()
            a=float(a[0].strip('<'))
        except Exception:
            a=0
        try:
            b=arr[3].split()
            b=float(b[0].strip('<'))
        except Exception:
            b=0
        try:
            c=arr[4].split()
            c=float(c[0].strip('<'))
        except Exception:
            c=0
        
        self.getAvg(totle, a, count)
        self.getAvg(totle, b, count)
        self.getAvg(totle, c, count)
        
        if count[0]==3:
            return {'resp_time':0, 'loss':100, 'isloss':True,'ip':ip}
        else:
            return {'resp_time':float("%.2f"%(max(totle))), 'loss':0, 'isloss':False,'ip':ip}

    
    def getRespAvgWin(self, arr):
        totle=[]
        count=[0]
        
        try:
            a=arr[0].split()
            a=float(a[0].strip('<'))
        except Exception:
            a=0
        try:
            b=arr[1].split()
            b=float(b[0].strip('<'))
        except Exception:
            b=0
        try:
            c=arr[2].split()
            c=float(c[0].strip('<'))
        except Exception:
            c=0
        
        self.getAvg(totle, a, count)
        self.getAvg(totle, b, count)
        self.getAvg(totle, c, count)
        
        if count[0]==3:
            return {'resp_time':0, 'loss':100, 'isloss':True}
        else:  
            return {'resp_time':float("%.2f"%(max(totle))), 'loss':0, 'isloss':False}
        

    def UTFdata(self, data):
        resp_result = 1
        resp_status = 'Trace OK'
        resp_err = '0'
        resp_time = 0
        no_resps=0
        steps=0
        max_loss=0
        loss_step=0
        ip=' '
        isok=False
        hasResp=False
        try:
            data=data.strip("\n")
            lines=data.split("\n")
            steps=len(lines)-1
            rem = re.compile("\(([0-9.]+)\)",re.M)
            arr = rem.findall(lines[0])
            if arr:
                ip=arr[0]
            for line in lines:
                #line=line.replace('  * ', '  ')
                line=line.replace('*', ' * ')
                arr=line.split()
                if len(arr)<5:
                    no_resps+=1
                else:
                    result=self.getRespAvg(arr)
                    resp_time=result['resp_time']
                    cur_ip=result['ip']
                    loss=result['loss']
                    isloss=result['isloss']
                    if isloss:
                        loss_step+=1
                    
                    if resp_time==0 :
                        no_resps+=1
                    else:
                        if max_loss < loss:
                            max_loss=loss
                    if cur_ip==ip:
                        isok=True
                    if resp_time>0:
                        hasResp=True
                    
        except Exception :
            jkbLib.error(self.logHead + traceback.format_exc())
            self.errorInfoDone(traceback.format_exc())
        
        if  not isok  and not hasResp:
            resp_time=0
            resp_result = 0
            resp_status = 'Trace LOSS'
            self.intStatus()
            
        if not isok and hasResp:
            resp_time=0
            resp_result = 0
            if jkbLib.getPythonVer()[0]=='3':
                resp_status = '未达指定IP'
            else:
                resp_status = unicode('未达指定IP','utf-8')
        
        resp = {'resp_result' :resp_result,'resp_status' : resp_status,'resp_time' : resp_time,
        'resp_err' : resp_err,'tracerouteExtend' : {'raw_data' : lines,'no_resps' : no_resps - 1,
        'steps' : steps, 'max_loss':max_loss, 'loss': int(loss_step/steps),'ip':ip}}
        return resp
        

    def UTFWindowsdata(self, data):
        resp_result = 1
        resp_status = 'Trace OK'
        resp_err = '0'
        resp_time = 0
        no_resps=0
        steps=0
        max_loss=0
        loss_step=0
        ip=' '
        isok=False
        hasResp=False
        try:
            data=data.strip("\r\n")
            lines=data.split("\r\n")
            rem = re.compile("([0-9]+[.]+[0-9]+[.]+[0-9]+[.]+[0-9]+)",re.M)
            arr = rem.findall(lines[0])
            if arr:
                ip=arr[0]
            else:
                arr = rem.findall(lines[1])
                if arr:
                     ip=arr[0]
            for line in lines:
                line=line.replace('*', '* ms')
                rem = re.compile("([^ ]* ms)[ ]{2,6}",re.M)
                arr = rem.findall(line)
                if len(arr)<3:
                    continue
                else:
                    rem = re.compile("([0-9]+[.]+[0-9]+[.]+[0-9]+[.]+[0-9]+)",re.M)
                    arr2 = rem.findall(line)
                    cur_ip=''
                    if arr2:
                        cur_ip=arr2[0]
                        
                    if cur_ip==ip:
                        isok=True
                    steps+=1
                    result=self.getRespAvgWin(arr)
                    resp_time=result['resp_time']
                    loss=result['loss']
                    isloss=result['isloss']
                    if resp_time>0:
                        hasResp=True
                    if isloss:
                        loss_step+=1
                    
                    if resp_time==0 :
                        no_resps+=1
                    else:
                        if max_loss < loss:
                            max_loss=loss
                
            
        except Exception :
            jkbLib.error(self.logHead + traceback.format_exc())
            self.errorInfoDone(traceback.format_exc())
        
        if  not isok  and not hasResp:
            resp_time=0
            resp_result = 0
            resp_status = 'Trace LOSS'
            self.intStatus()
            
        if not isok and hasResp:
            resp_time=0
            resp_result = 0
            if jkbLib.getPythonVer()[0]=='3':
                resp_status = '未达指定IP'
            else:
                resp_status = unicode('未达指定IP','utf-8')
            self.intStatus()
            
        resp = {'resp_result' :resp_result,'resp_status' : resp_status,'resp_time' : resp_time,
        'resp_err' : resp_err,'tracerouteExtend' : {'raw_data' : lines,'no_resps' : no_resps,
        'steps' : steps, 'max_loss':max_loss, 'loss': int(loss_step/steps),'ip':ip}}
        return resp

    def GBKdata(self, data):
        try:
            import sys
            reload(sys)
            sys.setdefaultencoding('utf-8')
        except Exception :
            pass
        resp_result = 1
        resp_status = 'Trace OK'
        resp_err = '0'
        resp_time = 0
        no_resps=0
        steps=0
        max_loss=0
        loss_step=0
        ip='1'
        isok=False
        hasResp=False
        try:
            data=data.strip("\r\n")
            lines=data.split("\r\n")
            rem = re.compile("([0-9]+[.]+[0-9]+[.]+[0-9]+[.]+[0-9]+)",re.M)
            arr = rem.findall(lines[0])
            if arr:
                ip=arr[0]
            else:
                arr = rem.findall(lines[1])
                if arr:
                     ip=arr[0]
            for line in lines:
                try:
                    line2=line.encode('GBK')
                    line2=line2.replace('<1 毫秒'.encode('GBK'), '1 ms ')
                    line=line2.replace('*', '* ms')
                except Exception :
                    line=line.replace('<1 毫秒', '1 ms ')
                    line=line.replace('*', '* ms')
                
                rem = re.compile("([^ ]* ms)[ ]{2,6}",re.M)
                arr = rem.findall(line)
                if len(arr)<3:
                    continue
                else:
                    rem = re.compile("([0-9]+[.]+[0-9]+[.]+[0-9]+[.]+[0-9]+)",re.M)
                    arr2 = rem.findall(line)
                    cur_ip=''
                    if arr2:
                        cur_ip=arr2[0]
                        
                    if cur_ip==ip:
                        isok=True
                    steps+=1
                    result=self.getRespAvgWin(arr)
                    resp_time=result['resp_time']
                    loss=result['loss']
                    isloss=result['isloss']
                    if resp_time>0:
                        hasResp=True
                    if isloss:
                        loss_step+=1
                    if resp_time==0 :
                        no_resps+=1
                    else:
                        if max_loss < loss:
                            max_loss=loss
            
        except Exception :
            jkbLib.error(self.logHead + traceback.format_exc())
            self.errorInfoDone(traceback.format_exc())
        
        if  not isok  and not hasResp:
            resp_time=0
            resp_result = 0
            resp_status = 'Trace LOSS'
            self.intStatus()
            
        if not isok and hasResp:
            resp_time=0
            resp_result = 0
            if jkbLib.getPythonVer()[0]=='3':
                resp_status = '未达指定IP'
            else:
                resp_status = unicode('未达指定IP','utf-8')
            self.intStatus()
            
        resp = {'resp_result' :resp_result,'resp_status' : resp_status,'resp_time' : resp_time,
        'resp_err' : resp_err,'tracerouteExtend' : {'raw_data' : lines,'no_resps' : no_resps,
        'steps' : steps, 'max_loss':max_loss, 'loss': int(loss_step/steps),'ip':ip}}
        return resp

    def getRaceData(self):
        host=self.taskConf['host']
        
        try :
            if self.sys_type == 'Windows':
                cmd='tracert -d -w 1000 '+host
            else:
                cmd='traceroute  -Inn -q 3 -w 1 '+host
            
            returnstr=subprocess.Popen(cmd,stdout=subprocess.PIPE,stderr=subprocess.PIPE, shell=True)
            data = returnstr.stdout.read()
            error= returnstr.stderr.read()
            try :
                data_re = data.decode('utf-8')
            except Exception:
                data_re = data.decode('GBK')

            if len(data_re.split("\n"))<4 and data_re!='' and self.sys_type == 'Windows':
                error='trace error:'+data_re
            try:
                self.close_proc(returnstr)
            except Exception :
                pass
            if error and error.find('Note:')==0 and data:
                error=''
            if error:
                if type(error)==str:
                    jkbLib.error(self.logHead + error)
                    self.errorInfoDone(error)
                    resp = {'resp_result' :0,'resp_status' : 'Trace LOSS','resp_time' : 0,
                    'resp_err' : '','tracerouteExtend' : {'raw_data' : [error],'no_resps' : 0,'steps' : 0, 'max_loss':0, 'loss': 0,'ip':''}}
                    return resp
                else:
                    try:
                        error = error.encode('utf-8', 'ignore').decode('utf-8')
                    except Exception:
                        error = error.encode('GBK', 'ignore').decode('GBK')
                    jkbLib.error(self.logHead + error)
                    self.errorInfoDone(error)
                    resp = {'resp_result' :0,'resp_status' : 'Trace LOSS','resp_time' : 0,
                    'resp_err' : '','tracerouteExtend' : {'raw_data' : [error],'no_resps' : 0,'steps' : 0, 'max_loss':0, 'loss': 0,'ip':''}}
                    return resp
            
            try :
                data = data.decode('utf-8')
                if self.sys_type=='Windows':
                    data =self.UTFWindowsdata(data)
                else:
                    data =self.UTFdata(data)
            except Exception:
                data = data.decode('GBK')
                data =self.GBKdata(data)
            
            self.intStatus()
            return data
        except Exception :
            jkbLib.error(self.logHead + traceback.format_exc())
            self.errorInfoDone(traceback.format_exc())
            resp = {'resp_result' :0,'resp_status' : 'Trace LOSS','resp_time' : 0,
                    'resp_err' : '','tracerouteExtend' : {'raw_data' : '','no_resps' : 0,'steps' : 0, 'max_loss':0, 'loss': 0,'ip':''}}
            return resp


    def getData(self):
        status_content = {}
        status_content=self.getRaceData()
        self.setData(status_content)

