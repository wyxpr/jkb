# -*- coding: utf-8 -*-
"""
 Copyright © 2012 云智慧（北京）科技有限公司 <http://www.jiankongbao.com/>
 
 Permission is hereby granted, free of charge, to any person obtaining a copy of this software
 and associated documentation files (the "Software"), to deal in the Software without restriction,
 including without limitation the rights to use, copy, modify, merge, publish, distribute,
 sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:
 
 The above copyright notice and this permission notice shall be included in all copies or
 substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND 
 NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, 
 DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE. 
"""
"""
Jiankongbao http plugin
sevn.huo@yunzhihui.com
"""


import time
from lib import jkbLib
from config import jkbConfig
import traceback
import re
from p_class import plugins
import socket
import math
import random
import subprocess

try:    
    import StringIO
except ImportError:
    import io as StringIO
try:
    import urlparse
except ImportError:    
    from urllib.parse import urlparse
try:
    from  urllib import parse
except ImportError:
    import urllib as parse

try:
    import json
except ImportError:
    import simplejson as json

class HttpPlugin(plugins.plugin):

    def __init__(self,taskId,taskConf,taskType):
        plugins.plugin.__init__(self,taskId,taskConf,taskType)
        self.size_limit=1024*1024
        self.homePath = ''
        self.sysType=jkbLib.UsePlatform()
        if self.sysType == 'Windows' :
            self.homePath = jkbLib.getPath()
        if hasattr(jkbConfig,'httpTimeOut'):
            self.timeOut=jkbConfig.httpTimeOut
        else:
            self.timeOut=15

    def microtime(self, get_as_float = True) :
        if get_as_float:
            return time.time()
        else:
            return '%f %d' % math.modf(time.time())

    
    def getResponseCodeDescribe(self,code):
        aCodeDescribe={'200':'OK','201':'Created','202':'Accepted','203':'Non-Authoritative Information',
        '204':'No Content','205':'Reset Content','206':'Partial Content','300':'Multiple Choices',
        '301':'Moved Permanently','302':'Move temporarily','303':'See Other','304':'Not Modified',
        '305':'Use Proxy','306':'Switch Proxy','307':'Temporary Redirect','400':'Bad Request',
        '401':'Unauthorized','403':'Forbidden','404':'Not Found','405':'Method Not Allowed',
        '406':'Not Acceptable','407':'Proxy Authentication Required','408':'Request Timeout',
        '409':'Conflict','410':'Gone','411':'Length Required','412':'Precondition Failed',
        '413':'Request Entity Too Large','414':'Request-URI Too Long','415':'Unsupported Media Type',
        '416':'Requested Range Not Satisfiable','417':'Expectation Failed','422':'Unprocessable Entity',
        '423':'Locked','424':'Failed Dependency','425':'Unordered Collection','426':'Upgrade Required',
        '449':'Retry With','500':'Internal Server Error','501':'Not Implemented','502':'Bad Gateway',
        '503':'Service Unavailable','504':'Gateway Timeout','505':'HTTP Version Not Supported',
        '506':'Variant Also Negotiates','507':'Insufficient Storage','509':'Bandwidth Limit Exceeded','510':'Not Extended',
        '600':'Unparseable Response Headers'}
        code=str(code)
        if code in aCodeDescribe:
            return aCodeDescribe[code]
        else:
            return "Error Response Status Code"
            
    def getnodeCode(self,code,syscall):
        cs={'6':['ENOTFOUND_getaddrinfo','EAI_AGAIN_getaddrinfo','EAI_FAIL_getaddrinfo','ENOENT_getaddrinfo'],
        '28':['ESOCKETTIMEDOUT_','ETIMEDOUT_connect'],
        '52':['ECONNRESET_'],
        '7':['ECONNREFUSED_connect']}
        key=code+'_'+syscall
        for one in cs:
            if key in cs[one]:
                return int(one)
        return 53
    
    def getHttpDataByNode(self,url,maxRedirects,method,header,cookie,post_data,h_user,h_pwd):
        pa=jkbLib.getPath()+"node"
        par=pa.split(':')
        cmd=[str(par[0])+':&&cd '+pa+' &&node request_test.js']
        cmd.append('-U "'+url+'"')
        if maxRedirects:
            cmd.append('-R '+str(maxRedirects))
            cmd.append('-F  true')
        else:
            cmd.append('-F  false')
        cmd.append('-t 20000')
        cmd.append('-T 5000')
        if url[0:5]=='https':
            cmd.append('-k false')
            cmd.append('-T 10000')
        cmd.append('-M "'+method+'"')
        cmd.append('-H "User-Agent:Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/43.0.2357.130 Safari/537.36 JianKongBao Monitor 1.1"')
        if header:
            rem = re.compile(r'([^:\n ]*):([^\n\r]*)',re.M)
            matches = rem.findall(header)
            if matches:
                for val in matches:
                    cmd.append('-H "'+str(val[0])+': '+str(val[1])+'"')
            
        if cookie:
            cmd.append('-C "'+cookie+'"')
        if post_data:
            cmd.append("-D '"+post_data+"'")
        if h_user:
            cmd.append('-u "'+str(h_user)+'"')
            cmd.append('-p "'+str(h_pwd)+'"')
        cmd.append(' &&cd ..')
        c=' '.join(cmd)
        if jkbConfig.debug:
            jkbLib.debug(c)
        ret=jkbLib.docmd(c)
        if ret['e'] :
            jkbLib.error(ret['e'])
        ret['d']=ret['d'].strip('\n')
        null='null'
        false='false'
        true='true'
        data=eval(ret['d'])
        if jkbConfig.debug:
            if 'body' in data:
                tmp=data['body']
                data['body']=''
                jkbLib.debug(data)
                data['body']=tmp
            else:
                jkbLib.debug(data)
        return data
        
    def getDnsByhost(self,host):
        pa=jkbLib.getPath()+"node"
        par=pa.split(':')
        c=str(par[0])+':&&cd '+pa+' &&node dns_test.js -H "'+str(host)+'"'
        if jkbConfig.debug:
            jkbLib.debug(c)
        ret=jkbLib.docmd(c)
        if ret['e'] :
            jkbLib.error(ret['e'])
            return {"ip":"","error":ret['e'],"namelookup_time":0}
        data=eval(ret['d'])
        if jkbConfig.debug:
            jkbLib.debug(data)
        return data
        
    def getHttpDataByCmd(self):
        resp = {}
        try:
            null='null'
            false='false'
            true='true'
            url=self.taskConf['url']
            url=url.replace('\/', "/")
            originalUrl=url
            ip = self.taskConf['ip']
            header = self.taskConf['header']
            if self.taskConf['patternType']=='':
                pattern_type=0
            else:
                pattern_type = int(self.taskConf['patternType'])
            pattern_str = self.taskConf['patternStr']
            if self.taskConf['submitMethod']=='':
                submit_method=0
            else:
                submit_method = int(self.taskConf['submitMethod'])
            if 'patternTarget' in self.taskConf:
                pattern_target=int(self.taskConf['patternTarget'])
            else:
                pattern_target=0
            if pattern_target=='':
                pattern_target=0

            if 'redirect' not in self.taskConf:
                self.taskConf['redirect']=0
                
            if 'redirectTimes' not in self.taskConf:
                self.taskConf['redirectTimes']=3
                
            if int(self.taskConf['redirectTimes'])!=3:
                self.taskConf['redirectTimes']=5
        
            al_type=['http', 'https']
            try:
                urlInfo=urlparse.urlparse(url)
            except Exception :
                urlInfo=urlparse(url)
            urlH = urlInfo.netloc.split(':')
            host=urlH[0]
            url_scheme=''
            if urlInfo.scheme not in al_type or host == '':
                jkbLib.error(self.logHead + "can't match the url")
                self.errorInfoDone("can't match the url")
                return False
            
            hostInfo=''
            try:
                dns_resolve_start_time = self.microtime()
                if self.sysType == 'Windows' :
                    ret=self.getDnsByhost(host)
                    if ret['error']!='' and not ip:
                        return {"resp_status":"HTTP_ERR_RESOLVE_HOST","resp_result":0,"resp_time":"0","httpExtend":{"errno":"","errmsg":"none agent info return","ip":""},"resp_err":"DNS Lookup Failed"}
                    hostInfo=['a','b',[ret['ip']]]
                    dns_resolve_time=ret['namelookup_time']
                else:
                    hostInfo = socket.gethostbyname_ex(host)
                    dns_resolve_end_time = self.microtime()
                    dns_resolve_time = (dns_resolve_end_time - dns_resolve_start_time)*1000
                    dns_resolve_time = round(float(dns_resolve_time),3)
            except Exception :
                if not ip:
                    return {"resp_status":"HTTP_ERR_RESOLVE_HOST","resp_result":0,"resp_time":"0","httpExtend":{"errno":"","errmsg":"none agent info return","ip":""},"resp_err":"DNS Lookup Failed"}
                dns_resolve_end_time = self.microtime()
                dns_resolve_time = (dns_resolve_end_time - dns_resolve_start_time)*1000
                dns_resolve_time = round(float(dns_resolve_time),3)

            url_ip = ''
            if ip:
                url_ip = ip
            else :
                lens = len(hostInfo[2])
                IP_key = random.randint(0, lens)
                IP_key = IP_key - 1
                url_ip = hostInfo[2][IP_key]
            
            if url_ip != host:
                url=url.replace(host, url_ip)
                if header:
                    if header.lower().find('host:') <0 :
                        header=header+"\nHost:"+urlInfo.netloc
                else:
                    header="Host:"+urlInfo.netloc
                    
            if self.sysType == 'Windows':
                maxRedirects=''
                req_method='GET'
                post_data=''
                h_user=''
                h_pwd=''
                cookie=self.taskConf['cookies']
                if urlInfo.scheme == 'https':
                    url=originalUrl
                if int(self.taskConf['redirect'])!=0:
                    maxRedirects=self.taskConf['redirectTimes']
                if submit_method==1:
                    req_method='POST'
                    if self.taskConf['param']!='':
                        parms={}
                        parm=self.taskConf['param'].replace(' ','')
                        parm=parm.replace('\r','')
                        parm=parm.replace('\n','')
                        if parm[0]=='{':
                            parm=parm.replace('&#039;','"')
                            parms=parm.replace('&quot;','"')
                            parms=eval(parms)
                        else:
                            parm=parm.replace('&amp;','&')
                            rem = re.compile(r'([^&]*)=([^&]*)',re.M)
                            matches = rem.findall(parm)
                            if matches:
                                for val in matches:
                                    parms[val[0]]=val[1]
                        post_data=''           
                        for k in parms:
                            post_data+=str(k)+'='+str(parms[k])+'&'
                        post_data=post_data.strip('&')
                elif submit_method==2:
                    req_method='HEAD'
                if self.taskConf['httpUser']!='':
                    h_user=str(self.taskConf['httpUser'])
                    h_pwd=str(self.taskConf['httpPwd'])
                node=self.getHttpDataByNode(url,maxRedirects,req_method,header,cookie,post_data,h_user,h_pwd)
                
                connect_time=node['timingPhases']['wait']+node['timingPhases']['tcp']
                total_time=node['timingPhases']['total']
                namelookup_time=node['timingPhases']['wait']+node['timingPhases']['dns']
                if 'pretransferTime' in node['timings']:
                    pretransfer_time=node['timings']['pretransferTime']
                else:
                    pretransfer_time=connect_time
                starttransfer_time=node['timingPhases']['firstByte']+node['timingPhases']['wait']+node['timingPhases']['tcp']
                
                
                header_s=''
                header_a=[]
                resp_data=''
                http_code=0
                size_download=0
                speed_download=0
                header_size=0
                errno = 0 
                errmsg=''
                if 'error' in node:
                    co=node['error']['code']
                    syscall=node['error']['syscall']
                    errno=self.getnodeCode(co,syscall)
                    errmsg=co+'_'+syscall
                else:
                    header_a=node['header']
                    size_download=len(node['body'])
                    if size_download>0:
                        speed_download=size_download/node['timingPhases']['download']*1000
                    
                    for one in header_a:
                        if type(header_a[one])==list:
                            header_s+=str(one)+': '+'; '.join(header_a[one])
                        else:
                            header_s+=str(one)+': '+str(header_a[one])+'\n'
                             
                    resp_data = str(node['body'])
                    http_code = node['code']
                    if header_s!='':
                        header_size=len(header_s)

            else:
                
                cmd=[self.homePath+'curl']       
                
                if urlInfo.scheme == 'https':
                    cmd.append('-k')
                    cmd.append('--connect-timeout 15')
                else:
                    cmd.append('--connect-timeout 5')
                
                if int(self.taskConf['redirect'])!=0:
                    if '-k' not in cmd:
                        cmd.append('-k')
                    cmd.append('-L')
                    cmd.append('--max-redirs '+str(self.taskConf['redirectTimes']))
                    
                cmd.append('-i')
                cmd.append('-m '+str(self.timeOut))
                
                if self.taskConf['httpUser']!='':
                    cmd.append('-u "'+str(self.taskConf['httpUser'])+':'+str(self.taskConf['httpPwd'])+'"')
                if self.taskConf['cookies']!='':
                    cmd.append('-b "'+str(self.taskConf['cookies'])+'"')
                    
                cmd.append('--compressed')
                header=header+"\nUser-Agent:Mozilla/5.0 (Macintosh; Intel Mac OS X 10_10_3) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/43.0.2357.130 Safari/537.36 JianKongBao Monitor 1.1"
                if header!='':
                    rem = re.compile(r'([^:\n ]*):([^\n\r]*)',re.M)
                    matches = rem.findall(header)
                    if matches:
                        for val in matches:
                            cmd.append('-H "'+str(val[0])+': '+str(val[1])+'"')
                    
                req_method = 'GET'
                if submit_method==0:
                    cmd.append('-G')
                if submit_method==1:
                    req_method = 'POST'
                    if self.taskConf['param']!='':
                        parms={}
                        parm=self.taskConf['param'].replace(' ','')
                        parm=parm.replace('\r','')
                        parm=parm.replace('\n','')
                        if parm[0]=='{':
                            parm=parm.replace('&#039;','"')
                            parms=parm.replace('&quot;','"')
                            #parms=eval(parms)
                        else:
                            parm=parm.replace('&amp;','&')
                            rem = re.compile(r'([^&]*)=([^&]*)',re.M)
                            matches = rem.findall(parm)
                            if matches:
                                for val in matches:
                                    parms[val[0]]=val[1]
      

                            parms = parse.urlencode(parms)
                            parms=parms.encode('UTF8')  
                        cmd.append("-d '"+str(parms)+"'")                  
                    
                if submit_method==2:
                    req_method = 'HEAD'
                    cmd.append('-X HEAD')
                
                cmd.append('-w ++end++%{http_code}:%{size_download}:%{time_connect}:%{speed_download}:%{time_total}:%{time_namelookup}:%{time_pretransfer}:%{time_starttransfer}:%{size_header}')
                if urlInfo.scheme == 'https':
                    cmd.append('"'+str(originalUrl)+'"')
                else:
                    cmd.append('"'+str(url)+'"')
                c=' '.join(cmd)
                if jkbConfig.debug:
                    jkbLib.debug(c)
                vet=jkbLib.docmd(c)
                if vet['d']=='':
                    if vet['e']!='':
                        jkbLib.error(self.logHead + vet['e'])
                        self.errorInfoDone(vet['e'])
                    return False
                errno=0
                errmsg=''
                if vet['e']!='':

                    try:
                        e_arr=vet['e'].split('curl: ')
                        e_arr=e_arr[-1].split()
                        errno=int(e_arr[0].strip('()'))
                        errmsg=' '.join(e_arr[1:])
                    except Exception :
                        errno=0
                        errmsg=''
                    
                    
                arr=vet['d'].split('++end++')
                if jkbConfig.debug:
                    jkbLib.debug(arr[-1])
                info=arr[-1].split(':')
                http_code=0
                try:
                    http_code=int(info[0])
                except Exception :
                    http_code = 0
                if http_code == 0 and errno == 0:
                    return {"resp_status":"HTTP_ERR_CONNECT","resp_result":0,"resp_time":"0","httpExtend":{"errno":"28","errmsg":"none agent info return","ip":""},"resp_err":"HTTP_ERR_CONNECT"}
                if http_code>0 and submit_method==2:
                    errno=0
                    
                size_download=int(info[1])
                connect_time=float(info[2])
                speed_download=float(info[3])
                total_time=float(info[4])
                namelookup_time=float(info[5])
                pretransfer_time=float(info[6])
                starttransfer_time=float(info[7])
                header_size=int(info[8])
                
                header_s=vet['d'][0:header_size]
                resp_data = vet['d'][header_size:len(arr[-1])*-1]
                
            
            
            
            resp_result= 1
            resp_err = '0'
            resp_status = ''
            resp_info={}
            
            h_arr=header_s.split('\n')
            http_content_length=-1
            for line in h_arr:
                h_tmp=line.split(':')
                if h_tmp[0].lower() == 'content-length':
                    http_content_length=int(h_tmp[1].strip())
            

            if errno != 0:
                resp_result=0
                if errno==6:
                    resp_status = 'HTTP_ERR_RESOLVE_HOST'
                elif errno==7:
                    resp_status = 'HTTP_ERR_CONNECT'
                elif errno==28:
                    resp_status = 'HTTP_ERR_TIMEOUT'
                    http_code=0
                    if connect_time > 0 and self.sysType!='Windows':
                        resp_status = 'HTTP_ERR_CONNECT'
                elif errno==52:
                    resp_status = 'HTTP_ERR_NO_REPLY'
                elif errno!='':
                    resp_status = 'HTTP_ERR_UNKNOWN'
                    
                resp_info={}
                resp_info['errno'] = errno
                resp_info['errmsg'] = errmsg.replace("'"," ")
                
                if errno!=6:
                    resp_info['ip'] = url_ip
                    

                #resp={'resp_result':resp_result,'resp_status':resp_status,'resp_time':0,'resp_err':resp_err,'httpExtend':resp_info}
                #return resp
            

            if http_code >= 400:
                resp_result = 0
            
            resp_info['size_download']=size_download
            if http_content_length != -1:
                resp_info['download_content_length']=http_content_length
            resp_info['http_code']=http_code
            resp_info['req_method']=req_method
            resp_info['req_httpv'] = "1.1"
            resp_info['speed_download']=speed_download
            if self.sysType != 'Windows':
                resp_info['total_time']=round(total_time*1000,3)
                resp_info['namelookup_time']=round(namelookup_time*1000,3)
                resp_info['connect_time']=round(connect_time*1000,3)
                resp_info['pretransfer_time']=round(pretransfer_time*1000,3)
                resp_info['starttransfer_time']=round(starttransfer_time*1000,3)
            else:
                resp_info['total_time']=total_time
                resp_info['namelookup_time']=namelookup_time
                resp_info['connect_time']=connect_time
                resp_info['pretransfer_time']=pretransfer_time
                resp_info['starttransfer_time']=starttransfer_time
            
            if urlInfo.scheme == 'https' and self.sysType != 'Windows':
                dns_resolve_time_diff = 0
            else:
                dns_resolve_time_diff = round(dns_resolve_time - resp_info['namelookup_time'],4)
            
            if not ip:
                resp_info['namelookup_time'] += dns_resolve_time_diff
            else:
                dns_resolve_time_diff=0

            if url_ip == host:
                resp_info['namelookup_time'] = 0
                dns_resolve_time_diff = 0
                
            resp_info['total_time'] += dns_resolve_time_diff    
            resp_info['connect_time'] += dns_resolve_time_diff
            resp_info['pretransfer_time'] += dns_resolve_time_diff
            resp_info['starttransfer_time'] += dns_resolve_time_diff
            
            if errno == 28:
                resp_status = 'HTTP_ERR_TIMEOUT'
                http_code=0
                if resp_info['connect_time'] > 0 and self.sysType!='Windows':
                    resp_status = 'HTTP_ERR_CONNECT'

            resp_info['ip'] = url_ip
            
            resp_info['header_size'] = header_size
            resp_headers={}
            if resp_info['header_size']!=0:
                tmp=header_s.split("\n")
                statusline = tmp[0]
                if statusline[0:4]== 'HTTP':
                    statustmp = statusline.split(" ")
                    vertmp = statustmp[0].split("/")
                    resp_info['resp_httpv'] = vertmp[1]
                    if not resp_status:
                        resp_status = str(resp_info['http_code'])+" "+self.getResponseCodeDescribe(resp_info['http_code'])
                else:
                    resp_info['resp_httpv']=''
                    if not resp_status:
                        resp_status = str(resp_info['http_code'])+" "+self.getResponseCodeDescribe(resp_info['http_code'])
                
                header_cookie=[]
                for line in tmp:
                    line=line.replace("\r", "").strip()
                    arrs=line.split(':')
                    if len(arrs) <2:
                        continue
                    if len(arrs) >2:
                        arrs[1]=':'.join(arrs[1:])
                    header_key = arrs[0]
                    header_val = arrs[1]
                    if header_key == 'Set-Cookie':
                        header_cookie.append(header_val.strip())
                    else:
                        resp_headers[header_key] = header_val.strip()
                    
                if header_cookie!=[]:
                    resp_headers['Set-Cookie'] = ', '.join(header_cookie)
                
            for key in resp_headers:
                value=resp_headers[key]
                if key.find("'") !=-1 or value.find("'") !=-1:
                    del resp_headers[key]
                    
            resp_info['resp_headers'] = resp_headers        
            
            needPatternAll = False
            if pattern_target != 1:
                pattern_target = 0
                needPatternAll=True
            
            if pattern_str.strip() != '' and http_code < 400 and http_code>0:
               
                try:
                    utf_body = resp_data.encode('utf8')
                    header_s = header_s.encode('utf8')
                    pattern_str=pattern_str.encode('utf8')
                except:
                    utf_body = resp_data.encode('gbk')
                    header_s = header_s.encode('gbk')
                    pattern_str=pattern_str.encode('gbk')

                if pattern_target==0:
                    if  pattern_type==0:
                        if  pattern_str not in  utf_body:
                            resp_result=0
                            resp_status = 'HTTP_ERR_NOT_PATTERN'
                    else:
                        if pattern_str  in utf_body :
                            resp_result=0
                            resp_status = 'HTTP_ERR_PATTERN'
                elif header_s:
                    if self.sysType =='Windows':
                        pattern_str=pattern_str.lower()
                        header_s=header_s.lower()
                    if  pattern_type==0:
                        if  pattern_str not in  header_s:
                            resp_result=0
                            resp_status = 'HTTP_HEADER_ERR_NOT_PATTERN'
                    else:
                        if pattern_str  in header_s :
                            resp_result=0
                            resp_status = 'HTTP_HEADER_ERR_PATTERN'
            
            if resp_info['starttransfer_time'] < resp_info['connect_time'] or resp_info['connect_time'] < resp_info['namelookup_time']:
                resp_err = '1'
            if resp_info['starttransfer_time']==0 and resp_info['connect_time']==0 and resp_info['namelookup_time']==0 and  resp_info['pretransfer_time']==0:
                resp_info['total_time']=0
            if resp_info['starttransfer_time']<resp_info['pretransfer_time']:
                resp_info['starttransfer_time']=resp_info['pretransfer_time']
                
            if resp_info['starttransfer_time']<0:
                resp_info['starttransfer_time']=0
            if resp_info['connect_time']<0:
                resp_info['connect_time']=0
            if resp_info['pretransfer_time']<0:
                resp_info['pretransfer_time']=0
            if resp_info['namelookup_time']<0:
                resp_info['namelookup_time']=0
            if resp_info['total_time']<0:
                resp_info['total_time']=0
                
            if resp_info['http_code']==0:
                del resp_info['http_code']


            self.intStatus()

            resp={'resp_result':resp_result,'resp_status':resp_status,'resp_time':resp_info['total_time'],'resp_err':resp_err,'httpExtend':resp_info}
            return resp
        except Exception :
            jkbLib.error(self.logHead + traceback.format_exc())
            self.errorInfoDone(traceback.format_exc())
            return False            

    def getData(self):
        status_content = {}
        status_content=self.getHttpDataByCmd()
        self.setData(status_content)
