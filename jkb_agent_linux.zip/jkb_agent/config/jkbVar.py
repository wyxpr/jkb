# -*- coding: utf-8 -*-
"""
 Copyright © 2012<http://www.jiankongbao.com/>
 
 Permission is hereby granted, free of charge, to any person obtaining a copy of this software
 and associated documentation files (the "Software"), to deal in the Software without restriction,
 including without limitation the rights to use, copy, modify, merge, publish, distribute,
 sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:
 
 The above copyright notice and this permission notice shall be included in all copies or
 substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND 
 NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, 
 DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE. 
"""
"""
Jiankongbao Global configurations.
sevn.huo@yunzhihui.com
"""


jkbServer = "http://v6-plugin.jiankongbao.com:8088"

jkbWebServer = "https://monitoring.cloudwise.com/monitoring"

versionUrl = jkbWebServer + "/agent/version"

configUrl = jkbServer + "/v1/agent/tasks"

postUrl = jkbServer + "/v1/data/task"

agentReg = jkbServer + "/v1/agent/register"

agentUp = jkbServer + "/v1/agent/update/"

agentCheck = jkbServer + "/v1/agent/check"

cmdGet = jkbServer + "/v1/agent/cmd/"

cmdDone = jkbServer + "/v1/agent/cmd"

heartbeat = jkbServer + "/v1/agent/heartbeat/"

pythonVer = ['2.6','2.7', '3.2','3.3','3.6']

agentId = ""

monitorId = ""

accountId = "246723"

userId = "378505"

serStats={}

plugStats={'http':{},'ping':{},'tcp':{},'traceroute':{}}

serverTimeDiff=0

upList={jkbWebServer+'/agent/upgrade?file=jkbAgent.py':'jkbAgent.py',
                jkbWebServer+'/agent/upgrade?file=/lib/jkbLib.py':'lib/jkbLib.py',
                jkbWebServer+'/agent/upgrade?file=/p_class/plugins.py':'p_class/plugins.py',
                jkbWebServer+'/agent/upgrade?file=/p_class/plugTask.py':'p_class/plugTask.py',
                jkbWebServer+'/agent/upgrade?file=/plugin/HttpPlugin.py':'plugin/HttpPlugin.py',
                jkbWebServer+'/agent/upgrade?file=/plugin/PingPlugin.py':'plugin/PingPlugin.py',
                jkbWebServer+'/agent/upgrade?file=/plugin/TcpPlugin.py':'plugin/TcpPlugin.py',
                jkbWebServer+'/agent/upgrade?file=/plugin/TracePlugin.py':'plugin/TracePlugin.py',
                jkbWebServer+'/agent/upgrade?file=/lib/mac.py':'lib/mac.py'}

