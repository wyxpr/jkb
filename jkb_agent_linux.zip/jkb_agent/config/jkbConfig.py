# -*- coding: utf-8 -*-
"""
 Copyright © 2012 云智慧（北京）科技有限公司 <http://www.jiankongbao.com/>
 
 Permission is hereby granted, free of charge, to any person obtaining a copy of this software
 and associated documentation files (the "Software"), to deal in the Software without restriction,
 including without limitation the rights to use, copy, modify, merge, publish, distribute,
 sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:
 
 The above copyright notice and this permission notice shall be included in all copies or
 substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND 
 NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, 
 DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE. 
"""
"""
Jiankongbao Global configurations.
sevn.huo@yunzhihui.com
"""

#采集器所用本地服务端口
agentPort='18080'

#自动更新的开关，True开，False关
autoUpdate=True

#代理服务器的开关，True开，False关，只影响采集器和监控宝服务器间的网络通信
useProxy=False

#代理服务器的host，useProxy为True时设置才生效
proxy_host=''

#代理服务器的port，useProxy为True时设置才生效
proxy_port=''

#http插件超时时间，单位秒
httpTimeOut=20

#插件数据上报速度慢阀值时间，单位秒
ReportTime=3

#采集器agentid是否固定，True是(不变agentId)，False否
isFixedAgentId=False

#采集器获取任务失败后，再次获取间隔,单位秒
getTaskFailedInterval=5

#采集器获取任务失败,重试次数
getTaskRetry=3

#采集器上报数据失败时，再次重试间隔,单位秒
postDataFailedInterval=3

#采集器上报数据失败时,重试次数
postDataRetry=3

#调试模式,True开，False关，默认False
debug=False

#任务分片处理，每片任务数
taskPicNum=20

#任务分片处理，每片执行时间
taskPicTime=30

#提交数据线程数
postProNum=3



