# -*- coding: utf-8 -*-
"""
 Copyright © 2012 云智慧（北京）科技有限公司 <http://www.jiankongbao.com/>
 
 Permission is hereby granted, free of charge, to any person obtaining a copy of this software
 and associated documentation files (the "Software"), to deal in the Software without restriction,
 including without limitation the rights to use, copy, modify, merge, publish, distribute,
 sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:
 
 The above copyright notice and this permission notice shall be included in all copies or
 substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND 
 NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, 
 DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE. 
"""
"""
Jiankongbao Master Process
sevn.huo@yunzhihui.com
"""


from config import jkbConfig
from config import jkbVar
from lib import jkbLib


import os
import sys
import time


import traceback
import threading
import subprocess

    
import signal 

try:
    import json
except ImportError:
    import simplejson as json

masterPid = os.getpid()

class MasterProcess(object):

    def __init__(self):
        self.lock = threading.Lock()
        self.agent = None


    def _send(self, msg):
        try:
            self.lock.acquire()

            if self.agent is None or self.agent.poll() is not None:
                return

            self.agent.stdin.write(msg)
            self.agent.stdin.flush()

            if msg == 'stop\n':
                time.sleep(1)
                self.agent = None

        finally:
            self.lock.release()

    def ping(self):
        return self._send('ping\n'.encode('UTF8'))

    def stop(self):
        return self._send('stop\n'.encode('UTF8'))
    
    def restart(self):
        return self._send('restart\n'.encode('UTF8'))
    


class AgentProcessMonitor(threading.Thread):

    def __init__(self, masterProcess,type):
        self.masterProcess = masterProcess
        self.type = type
        if jkbLib.UsePlatform() == 'Windows' :
            self.agentPath =jkbLib.getPath()+'jkbAgent.py'
            self.cmd = 'python'
        else :
            self.agentPath = os.path.join(sys.path[0],'jkbAgent.py')
            self.cmd = sys.executable
        threading.Thread.__init__(self)
        
    def __del__(self):
        jkbLib.rmPid('agent')
        jkbLib.rmPid('master')

    def _startAgentProcess(self):
        return subprocess.Popen([self.cmd,self.agentPath,str(masterPid),self.type],stdin=subprocess.PIPE, stdout=subprocess.PIPE)

    def run(self):
        while True:
            try:
                self.masterProcess.lock.acquire()
                try:
                    if  self.masterProcess.agent is None  or self.masterProcess.agent.poll() is not None :
                        self.masterProcess.agent = self._startAgentProcess()
                except Exception :
                    jkbLib.error(traceback.format_exc())
            finally:
                self.masterProcess.lock.release()
                time.sleep(8)


class AgentUpdater(threading.Thread):

    def __init__(self, config, agentDir, masterProcess):
        self.config = config
        self.agentDir = agentDir
        self.checkTime = 1800
        self.masterProcess = masterProcess
        self.homePath = ''
        if jkbLib.UsePlatform() == 'Windows' :
            self.homePath = jkbLib.getPath()
        threading.Thread.__init__(self)

    def run( self ):
        while True:
            try:
                time.sleep(self.checkTime)
                self.checkVer()
            except Exception :
                jkbLib.error(traceback.format_exc())
    
    def checkVer(self):
        resJson = jkbLib.get(jkbVar.versionUrl)
        
        if resJson==False:
            return False

        if 'version' not in resJson:
            return False
            
        if resJson['status']!='success':
            return False
            

        pf = open(self.homePath+'agentVersion.txt','r')
        self.agentVersion = pf.read().strip()
        pf.close()
        agentVersion = resJson['version']
        if agentVersion.strip("\n") != self.agentVersion.strip("\n"):
            self._upgradeAgent(agentVersion)
            return True
        return False
    
    def _upgradeAgent(self, newAgentVersion):
        try:
            self._downFile(self.config.upList)
            self.masterProcess.restart()
            jkbLib.info('new agent version: ' + newAgentVersion)
            open(self.homePath+'agentVersion.txt','w+').write("%s\n" % newAgentVersion)
            self.agentVersion = newAgentVersion
        except Exception :
            jkbLib.error(traceback.format_exc())

    def _downFile(self,lists):
        try:
            if jkbLib.UsePlatform() == 'Windows' :
                lists[self.config.jkbWebServer+'/agent/upgrade?file=serviceInstall.bat']='serviceInstall.bat'
                lists[self.config.jkbWebServer+'/agent/upgrade?file=serviceStart.bat']='serviceStart.bat'
                lists[self.config.jkbWebServer+'/agent/upgrade?file=serviceStop.bat']='serviceStop.bat'
                lists[self.config.jkbWebServer+'/agent/upgrade?file=serviceUnstall.bat']='serviceUnstall.bat'
                lists[self.config.jkbWebServer+'/agent/upgrade?file=start.bat']='start.bat'
                lists[self.config.jkbWebServer+'/agent/upgrade?file=stop.bat']='stop.bat'
            else:
                lists[self.config.jkbWebServer+'/agent/upgrade?file=start.sh']='start.sh'
                lists[self.config.jkbWebServer+'/agent/upgrade?file=stop.sh']='stop.sh'
            for one in lists:
                jkbLib.download(one,lists[one])
                jkbLib.info('update file :'+lists[one])
        except Exception :
            jkbLib.error(traceback.format_exc())


class Control : 
    def start(self,type=''):
        try:
            pid = jkbLib.readPid('master')
        except IOError:
            pid = 0   
        ip=jkbLib.get_ip()
        if jkbConfig.agentPort==0 or jkbConfig.agentPort=='':
            jkbLib.printout('agentPort is not Configuration')
            jkbLib.info('agentPort is not Configuration')
            sys.exit(1)
        if jkbLib.PortIsOpen(ip,jkbConfig.agentPort):
           jkbLib.printout('agentPort ('+str(jkbConfig.agentPort)+') is used')
           jkbLib.info('agentPort ('+str(jkbConfig.agentPort)+') is used')
           sys.exit(1)
           
        
        try:

            verInfo=jkbLib.getPythonVer()
            if verInfo not in jkbVar.pythonVer:
                verStr='/'.join(jkbVar.pythonVer)
                jkbLib.info('当前pyhon版本还没兼容，程序执行中止，目前支持python版本:'+verStr) 
                sys.exit(1)
            pid = str(masterPid)
            jkbLib.writePid(pid,'master')
            print('Starting master process')
            jkbLib.info('Starting master process') 
            masterProcess = MasterProcess()
            monitor = AgentProcessMonitor(masterProcess,type)
            monitor.setName('AgentProcessMonitor')
            monitor.setDaemon(True)
            monitor.start()
            if jkbConfig.autoUpdate:
                updater = AgentUpdater(jkbVar, sys.path[0], masterProcess)
                updater.setName('AgentUpdater')
                updater.setDaemon(True)
                updater.start()
            
            print('Started master process')
            jkbLib.info('Started master process')
            if type == 'service':
                jkbLib.info('Installing service JKBNewAgentService-'+str(jkbConfig.agentPort))

            while True:
                try:
                    time.sleep(5)
                    masterProcess.ping()
                except Exception :
                    jkbLib.error(traceback.format_exc())

        except KeyboardInterrupt:
            masterProcess.stop()
        except Exception :
            jkbLib.error(traceback.format_exc())

    def stop(self,type=''):
        try:
            pid = jkbLib.readPid('master')
            apid = jkbLib.readPid('agent')
        except IOError:
            pid = None
    
        if not pid:
            message = "The process does not exist, the operation aborts"
            jkbLib.printout(message)
            jkbLib.info(message)
            return # not an error in a restart
   
        try:
            systype = jkbLib.UsePlatform()
            while 1:
                if systype == 'Linux' :
                    os.kill(apid, signal.SIGTERM)
                    os.kill(pid, signal.SIGTERM)
                else :
                    if jkbLib.kill(pid) :
                        jkbLib.kill(apid)
                        jkbLib.rmPid('agent')
                        jkbLib.rmPid('master')
                        jkbLib.printout('Successful process closes')
                        jkbLib.info('Successful process closes')
                        if type == 'service':
                            jkbLib.info('Stopping service JKBNewAgentService-'+str(jkbConfig.agentPort))
                            jkbLib.info('Removing service JKBNewAgentService-'+str(jkbConfig.agentPort))
                        sys.exit(1)
                    else :
                        jkbLib.printout('Failed to process closes')
                        jkbLib.info('Failed to process closes')
                        jkbLib.rmPid('agent')
                        jkbLib.rmPid('master')
                        sys.exit(1)
                time.sleep(0.1)
        except OSError :
                jkbLib.rmPid('agent')
                jkbLib.rmPid('master')
        jkbLib.printout('Successful process closes')
        jkbLib.info('Successful process closes')


    def restart(self):
        self.stop()
        self.start()
        
    def check(self):
        try:
            pid = jkbLib.readPid('master')
        except IOError:
            pid = None
    
        if not pid:
            message = "Process has closed\n"
            sys.stderr.write(message)
        else:
            message = "The process has been run, the process id:%d\n"
            sys.stderr.write(message % pid)
            
    def helpInfo(self):
        jkbLib.printout("usage: %s install|start|stop|restart|check|help" % sys.argv[0])
        

if __name__ == "__main__":
    Contr=Control()
    if len(sys.argv) >= 2:
        if 'start' == sys.argv[1]:
            if len(sys.argv) >=3 and 'service' == sys.argv[2]:
                Contr.start('service')
            else:
                Contr.start()
        elif 'stop' == sys.argv[1]:
            if len(sys.argv) >=3 and 'service' == sys.argv[2]:
                Contr.stop('service')
            else:
                Contr.stop()
        elif 'restart' == sys.argv[1]:
            Contr.restart()
        elif 'check' == sys.argv[1]:
            Contr.check()
        elif 'help' == sys.argv[1]:
            Contr.helpInfo() 
        else:
            jkbLib.printout("未知命令")
            sys.exit(2)
    else:
        jkbLib.printout("usage: %s start|stop|restart|check|help" % sys.argv[0])
        sys.exit(2)
