# -*- coding: utf-8 -*-
"""
 Copyright © 2012 云智慧（北京）科技有限公司 <http://www.jiankongbao.com/>
 
 Permission is hereby granted, free of charge, to any person obtaining a copy of this software
 and associated documentation files (the "Software"), to deal in the Software without restriction,
 including without limitation the rights to use, copy, modify, merge, publish, distribute,
 sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:
 
 The above copyright notice and this permission notice shall be included in all copies or
 substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND 
 NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, 
 DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE. 
"""
"""
Jiankongbao lib
sevn.huo@yunzhihui.com
"""


import os
from os.path import basename
from config import jkbConfig

import time
import datetime

try:
    from urllib.parse import urlsplit
except ImportError:
    from urlparse import urlsplit
try:
    import urllib2
except ImportError:
    import urllib.request as urllib2
try:
    from  urllib import parse
except ImportError:
    import urllib as parse
try:
    import json
except ImportError:
    import simplejson as json
    
import traceback
import logging
import platform
from hashlib import md5
import ctypes 
import sys
import base64
import subprocess
import socket
import re
from multiprocessing import cpu_count
import uuid

pyVar = platform.python_version()
try:
    reload(sys)
    sys.setdefaultencoding('utf8')
except Exception:
    pass

def date(unixtime, format = '%m/%d/%Y %H:%M'):
    d = datetime.datetime.fromtimestamp(unixtime)
    return d.strftime(format)

def strtotime(timeStr, format = '%Y-%m-%d %H:%M:%S'):
    time_tuple = time.strptime(timeStr, format)
    timestamp = time.mktime(time_tuple)
    return int(timestamp)

cur_date={'i':date(time.time(),'%Y/%m/%d'),'e':date(time.time(),'%Y/%m/%d'),'d':date(time.time(),'%Y/%m/%d'),'s':date(time.time(),'%Y/%m/%d')}
    
def strDecode(thStr):
    tmp=''
    if pyVar[0]=='2':
        if type(thStr) == unicode:
            try:
                tmp=thStr.encode('GBK','ignore').decode('GBK')
            except Exception:
                try:
                    tmp=thStr.encode('utf-8','ignore').decode('utf-8')
                except Exception:
                    error(traceback.format_exc())
                    return thStr
        else:
            tmp=thStr
    else:
        if type(thStr) == bytes:
            try:
                tmp=thStr.decode('GBK','ignore')
            except Exception:
                try:
                    tmp=thStr.decode('utf-8','ignore')
                except Exception:
                    error(traceback.format_exc())
                    return thStr
        else:
            tmp=thStr
    return tmp
        
    
def info(thstr):
    global cur_date
    thstr=strDecode(thstr)
    logger = logging.getLogger('JKB_info')
    if cur_date['i'] != date(time.time(),'%Y/%m/%d') and logger.handlers:
        cur_date['i']=date(time.time(),'%Y/%m/%d')
        logger.handlers.pop()
    if not logger.handlers:
        FileHandler = logging.FileHandler(getPath()+'log/info_'+date(time.time(), format = '%Y-%m-%d')+'.log',encoding='utf-8')
        FileHandler.setFormatter(logging.Formatter('%(asctime)s %(levelname)s %(message)s'))
        logger.addHandler(FileHandler)
        logger.setLevel(logging.INFO)
    logger.info(thstr)
    return True

    
def error(thstr):
    global cur_date
    thstr=strDecode(thstr)
    logger = logging.getLogger('JKB_error')
    if cur_date['e'] != date(time.time(),'%Y/%m/%d') and logger.handlers:
        cur_date['e']=date(time.time(),'%Y/%m/%d')
        logger.handlers.pop()
    if not logger.handlers:
        FileHandler = logging.FileHandler(getPath()+'log/error_'+date(time.time(), format = '%Y-%m-%d')+'.log',encoding='utf-8')
        FileHandler.setFormatter(logging.Formatter('%(asctime)s %(levelname)s %(message)s'))
        logger.addHandler(FileHandler)
        logger.setLevel(logging.ERROR)
    logger.error(thstr)
    return True


def sysinfo(thstr):
    global cur_date
    thstr=strDecode(thstr)
    logger = logging.getLogger('JKB_sys')
    if cur_date['s'] != date(time.time(),'%Y/%m/%d') and logger.handlers:
        cur_date['s']=date(time.time(),'%Y/%m/%d')
        logger.handlers.pop()
    if not logger.handlers:
        FileHandler = logging.FileHandler(getPath()+'log/sys_'+date(time.time(), format = '%Y-%m-%d')+'.log',encoding='utf-8')
        FileHandler.setFormatter(logging.Formatter('%(asctime)s %(levelname)s %(message)s'))
        logger.addHandler(FileHandler)
        logger.setLevel(logging.INFO)
    logger.info(thstr)
    return True
    
def debug(thstr):
    global cur_date
    thstr=strDecode(thstr)
    logger = logging.getLogger('JKB_debug')
    if cur_date['d'] != date(time.time(),'%Y/%m/%d') and logger.handlers:
        cur_date['d']=date(time.time(),'%Y/%m/%d')
        logger.handlers.pop()
    if not logger.handlers:
        FileHandler = logging.FileHandler(getPath()+'log/debug_'+date(time.time(), format = '%Y-%m-%d')+'.log',encoding='utf-8')
        FileHandler.setFormatter(logging.Formatter('%(asctime)s %(levelname)s %(message)s'))
        logger.addHandler(FileHandler)
        logger.setLevel(logging.DEBUG)
    logger.debug(thstr)
    return True

def docmd(c):
    try:
        returnstr=subprocess.Popen(c,stdout=subprocess.PIPE,stderr=subprocess.PIPE, shell=True)
        data = returnstr.stdout.read()
        err = returnstr.stderr.read()
        returnstr.stdout.close()
        returnstr.stderr.close()
        try:
            if data!='':
                data=data.decode('utf-8','ignore')
        except Exception:
            if data!='':
                data=data.decode('GBK','ignore')
        if err!='':
            err=strDecode(err)
            if not (err.find('Received') and err.find('Xferd')):
                    error(err)
        return {'d':data,'e':err}
    except Exception:
        error(traceback.format_exc())
        return {'d':'','e':''}
        
def postRetry(url,parms={},time_out=3,retry=3):
        num=0
        while True:
            num+=1
            vet=post(url,parms,time_out)
            if vet != False:
                return vet
            if num>retry:
                return False
            time.sleep(3)
       
        
def post(url,parms={},time_out=3):
    try:
        try:
            parms = json.dumps(parms,ensure_ascii=False)
        except Exception:
            try:
                parms = json.dumps(parms,ensure_ascii=False, encoding='utf-8')
            except Exception:
                try:
                     parms = json.dumps(parms,ensure_ascii=False, encoding='GBK')
                except Exception:
                    error('json.dumps loss!')
                    error(traceback.format_exc())
                    return False
        parms=parms.encode('UTF8')
        headers={'Content-Type':'application/json'}
        res =  urllib2.urlopen(urllib2.Request(url, parms,headers=headers),timeout=time_out)
        ret = res.read()
        res.close()
        ret=ret.decode('UTF8')
        ret=json.loads(ret)
        if jkbConfig.debug:
            debug('url:'+url+' | parms:'+str(parms)+' | return:'+str(ret))
        return ret
    except Exception:
        if jkbConfig.debug:
            debug('url:'+url+' | parms:'+str(parms)+' | return:requst error')
        error('url:'+url+' | parms:'+str(parms))
        error(traceback.format_exc())
        return False
        
def get(url,time_out=3):
    try:
        res =  urllib2.urlopen(urllib2.Request(url),timeout=time_out)
        ret = res.read()
        res.close()
        ret=ret.decode('UTF8')
        ret=json.loads(ret)
        if jkbConfig.debug:
            debug('url:'+url+' | return:'+str(ret))
        return ret
    except Exception:
        if jkbConfig.debug:
            debug('url:'+url+' | return:requst error!!')
        error('url:'+url)
        error(traceback.format_exc())
        return False
        
def url2name(url):
    return basename(urlsplit(url)[2])
    
def PortIsOpen(ip,port):
    s = socket.socket(socket.AF_INET,socket.SOCK_STREAM)
    try:
        s.connect((ip,int(port)))
        s.shutdown(2)
        return True
    except:
        return False
        
def checkPidWin(pid=0):
    if int(pid)==0:
        return False
    cmd='tasklist /FI "PID eq '+str(pid)+'"  /FI "IMAGENAME eq python.exe "'
    data=docmd(cmd)
    if len(data['d']) > 150:
        return True
    else :
        return False

def checkPidLinux(pid=0):
    if int(pid)==0:
        return False
    cmd='ps ax |grep '+str(pid)+' |grep python|grep -v grep'
    data=docmd(cmd)
    if len(data['d']) > 20:
        return True
    else :
        return False

def download(url, localFileName = None):
    homePath = ''
    if UsePlatform() == 'Windows' :
        homePath = getPath()
    localName = url2name(url)
    req = urllib2.Request(url)
    r = urllib2.urlopen(req)
    if localFileName:
        # we can force to save the file as specified name
        try:
            localName = homePath + localFileName
        except:
            homePath=unicode(homePath,'GBK')
            localName = homePath + localFileName
    str_=r.read()
    f = open(localName, 'wb')
    f.write(str_)
    f.close()


def getMD5(strFile):
    try:
        fh = open(strFile, "rb")
        m = md5()
        strRead = ""

        while True:
            strRead = fh.read(8096)
            if not strRead:
                break
            m.update(strRead)
        bet = True
        strMd5 = m.hexdigest()
        if fh:
            fh.close()
    except:
        bet = False
        if fh:
            fh.close()
    if bet :
        return strMd5
    else:
        return bet
    
def readPid(pidType):
    pidPath=None
    homePath = ''
    if UsePlatform() == 'Windows' :
        homePath = getPath()
        
    if pidType=='agent':
        pidPath=homePath+'tmp/agentpid.pid'
    else :
        pidPath=homePath+'tmp/masterpid.pid'
    if os.path.exists(pidPath):
        pf = open(pidPath,'r')
        pid = int(pf.read().strip())
        if pid ==0 :
            pid =False
        pf.close()
        return pid
    else :
        return 0
        
    
def readLog():
    logPath=None
    homePath = ''
    if UsePlatform() == 'Windows' :
        homePath = getPath()
    logPath=homePath+'log/'+date(time.time(), format = '%Y-%m-%d')+'.log'
    if os.path.exists(logPath):
        pf = open(logPath,'r')
        logStr = pf.read().strip()
        return logStr
    else:
        return False
    
def writePid(pid,pidType):
    pidPath=None
    homePath = ''
    if UsePlatform() == 'Windows' :
        homePath = getPath()
    if pidType=='agent':
        pidPath=homePath+'tmp/agentpid.pid'
    else :
        pidPath=homePath+'tmp/masterpid.pid'
    pid = str(pid)
    pf = open(pidPath,'w')
    pf.write("%s\n" % pid)
    pf.close()

def rmPid(pidType):
    pidPath=None
    homePath = ''
    if UsePlatform() == 'Windows' :
        homePath = getPath()
    if pidType=='agent':
        pidPath=homePath+'tmp/agentpid.pid'
    else :
        pidPath=homePath+'tmp/masterpid.pid'
    pf = open(pidPath,'w')
    pf.write("0")
    pf.close()
    
def UsePlatform():
    sysstr = platform.system()
    if(sysstr =="Windows"):
        return 'Windows'
    elif(sysstr == "Linux"):
        return 'Linux'
    else:
        return 'Other'
        
def kill(pid):
    """kill function for Win32"""
    kernel32 = ctypes.windll.kernel32
    handle = kernel32.OpenProcess(1, 0, pid)
    return (0 != kernel32.TerminateProcess(handle, 0))

def getPath():
    str=os.path.split(os.path.realpath(__file__))
    str=os.path.split(str[0])
    return str[0]+'/'

def printout(data):
    sys.stderr.write(data+'\n')
    
def getPythonVer():
    var = platform.python_version()
    return var[0]+var[1]+var[2]


def decode(strdata, key):
    try:
        m = md5()
        key=key.encode('UTF8')  
        m.update(key)
        key = m.hexdigest()
        l = len(key)
        strdata=strdata.decode('UTF8')
        i = l-1
        while(i>=0):
            kk=str(ord(key[i]))
            le=len(kk)
            kk = kk[le-1:le]
            #tt = kk +'=' + key[i]
            strdata = str_remove(strdata, kk)
            if strdata == '' :
                return ''
            i-=1
        strdata = strdata.encode('UTF8')  
        strdata = base64.b64decode(strdata)
        strdata = strdata.decode('UTF8')
        return strdata
    except Exception :
        return ''
    
def str_remove(strdata, i):
    try:
        i = int(i)
        strdata = str(strdata)
        l = len(strdata)
        tmp_str = strdata
        j=0
        le = len(tmp_str)
        while(j < l):
            if j >= i  :
                if j+1 < le:
                    strdata=strdata[:j] + tmp_str[j+1] + strdata[j+1:]
                else:
                    strdata=strdata[:j] 
            j+=1
        return strdata
    except Exception :
        return ''

def get_mac_address():
    if UsePlatform() == 'Windows' :
        macPath =getPath()+'lib/mac.py'
    else :
        macPath = os.path.join(sys.path[0],'lib/mac.py')
    data=docmd('python '+macPath)
    return data['d'].strip('\r\n')


def getHostInfo():
    hostInfo={}
    hostInfo['hn']=socket.gethostname()
    hostInfo['cpu']=cpu_count()
    hostInfo['mac']=get_mac_address()
    hostInfo['ipv6']=''
    try:
        if UsePlatform() == 'Windows' :
            hostInfo['os']='Windows '+platform.release()+' v'+platform.version()
            cmd='net statistics WORKSTATION'
            data=docmd(cmd)
            rem = re.compile(r'(([0-9]*)/([0-9]*)/([0-9]*) ([0-9]*):([0-9]*):([0-9]*))',re.M)
            matches = rem.findall(data['d'])
            if matches:
                t=strtotime(matches[0][0],'%Y/%m/%d %H:%M:%S')
                hostInfo['runtime']=timesdiff(time.time()-t)
            
            cmd='ipconfig'
            data=docmd(cmd)
            rem = re.compile(r'(([a-f0-9]{1,4}:){7}[a-f0-9]{1,4})',re.M)
            matches = rem.findall(data['d'])
            if matches:
                hostInfo['ipv6']=matches[0][0]
        else:
            hostInfo['os']=platform.platform()
            cmd='cat /proc/uptime'
            data=docmd(cmd)
            ts=data['d']
            ar=ts.split(' ')
            hostInfo['runtime']=timesdiff(ar[0])
            hostInfo['freetime']=timesdiff(float(ar[1])/float(hostInfo['cpu']))
            
            cmd='ifconfig'
            data=docmd(cmd)
            rem = re.compile(r'(([a-f0-9]{1,4}:){7}[a-f0-9]{1,4})',re.M)
            matches = rem.findall(data['d'])
            if matches:
                hostInfo['ipv6']=matches[0][0]
    except Exception:
        pass
    hostInfo['ip'] = get_ip()
    hostInfo['bit']=platform.architecture()[0]
    return hostInfo

def timesdiff(diff):
    d=int(float(diff))
    return str(d / 86400)+'d '+str((d%86400)/3600)+'h '+str((d%3600)/60)+'m '+str(d%60)+'s'
 
def get_ip():
    if UsePlatform() == 'Windows' :
        try:
            myaddr = socket.gethostbyname(socket.gethostname())
        except Exception:
            myaddr = socket.gethostbyname(socket.gethostname().encode('GBK'))
        return myaddr
    ip='127.0.0.1'
    try:
        data=docmd('ip route')
        arr=data['d'].strip().split('\n')
        net=''
        iplist={}
        for line in arr:
            tmp=line.split()
            if line.lower().find('default via')>=0:
                net=tmp[4]
            else:
                tmp2=line.split(' src ')
                if len(tmp2)>1:
                    a=tmp2[1].strip().split()
                    iplist[tmp2[0]]=a[0].strip()
        if net=='':
            return ip
        for one in iplist:
            if one.find(net)>=0:
                return iplist[one]
    except Exception:
        error(traceback.format_exc())
    return ip

