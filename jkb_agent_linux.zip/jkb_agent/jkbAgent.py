# -*- coding: utf-8 -*-
"""
 Copyright © 2012 云智慧（北京）科技有限公司 <http://www.jiankongbao.com/>
 
 Permission is hereby granted, free of charge, to any person obtaining a copy of this software
 and associated documentation files (the "Software"), to deal in the Software without restriction,
 including without limitation the rights to use, copy, modify, merge, publish, distribute,
 sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:
 
 The above copyright notice and this permission notice shall be included in all copies or
 substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND 
 NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, 
 DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE. 
"""
"""
Jiankongbao Agent Process.
sevn.huo@yunzhihui.com
"""


from config import jkbConfig
from config import jkbVar
from p_class import plugTask
from lib import jkbLib

import os
import sys
import time
import socket
try:
    from importlib import reload
except Exception:
    from imp import reload
try:
    import zlib
except ImportError:
    zlib=''
try:
    import base64
except ImportError:
    base64=''

import threading
import traceback
import re

try:
    from BaseHTTPServer import BaseHTTPRequestHandler, HTTPServer
except ImportError:
    from http.server import BaseHTTPRequestHandler,HTTPServer
try:
    import urllib2
except ImportError:
    import urllib.request as urllib2
try:
    from  urllib import parse
except ImportError:
    import urllib as parse

try:
    import json
except ImportError:
    import simplejson as json

#proxy
try:
    if jkbConfig.useProxy :
        proxy_handler = urllib2.ProxyHandler({'http': str(jkbConfig.proxy_host)+':'+str(jkbConfig.proxy_port)})
        proxy_opener = urllib2.build_opener(proxy_handler)
        urllib2.install_opener(proxy_opener)
except Exception :
    pass
    
#https
if jkbVar.jkbServer[0:5] == 'https':
    import  ssl
    try :
        import httplib
    except ImportError:
        import http.client as httplib
    class HTTPSConnectionV3(httplib.HTTPSConnection):
        def __init__(self, *args, **kwargs):
            httplib.HTTPSConnection.__init__(self, *args, **kwargs)
             
        def connect(self):
            sock = socket.create_connection((self.host, self.port), self.timeout)
            if self._tunnel_host:
                self.sock = sock
                self._tunnel()
            try:
                self.sock = ssl.wrap_socket(sock, self.key_file, self.cert_file, ssl_version=ssl.PROTOCOL_SSLv23)
            except ssl.SSLError:
                self.sock = ssl.wrap_socket(sock, self.key_file, self.cert_file, ssl_version=ssl.PROTOCOL_SSLv3)
                 
    class HTTPSHandlerV3(urllib2.HTTPSHandler):
        def https_open(self, req):
            return self.do_open(HTTPSConnectionV3, req)
    # install opener
    urllib2.install_opener(urllib2.build_opener(HTTPSHandlerV3()))


class AgentProcess(threading.Thread):

    def __init__(self,startType):
        self.running = True
        self.pluStatus = 1
        self.objList = {}
        self.taskList = []
        self.taskAction = []
        self.hostInfo = {}
        self.plugInit = True
        self.getConfInterval=60*10
        self.postDataInterval=5
        self.getTaskRetry=0
        self.homePath = ''
        self.startType = startType
        if jkbLib.UsePlatform() == 'Windows' :
            self.homePath = jkbLib.getPath()
        threading.Thread.__init__(self)
        socket.setdefaulttimeout(15)
        
    def __del__(self):
        jkbLib.rmPid('agent')


    def exit(self):
        self.running = False
        #退出
        if jkbLib.UsePlatform()=='Windows':
            if self.startType=='service':
                jkbLib.docmd(self.homePath+'serviceUnstall.bat '+self.homePath)
            else:
                jkbLib.docmd('stop.bat')
        else:
            jkbLib.info('Successful process closes')
            jkbLib.docmd('bash ./stop.sh')
        jkbLib.rmPid('agent')
        os._exit(0) 
        
    def stop(self):
        self.running = False
        jkbLib.rmPid('agent')
        os._exit(0)         
    
    def run(self):
        self.objList = {}
        confTime=0
        postTime=0
        getTaskTime=0
        jkbVar.serStats['startedDate']=jkbLib.date(time.time()+jkbVar.serverTimeDiff, format = '%Y-%m-%d %H:%M:%S')
        jkbVar.serStats['status']='Running'
        jkbVar.serStats['details']={}
        if jkbVar.agentId != '':
            self.checkAgentId(True)
            self.getUsrPluginSet()
            self.doTask()
            confTime=time.time()
            getTaskTime=time.time()
        try:
            while self.running:
                if time.time()>confTime+self.getConfInterval:
                    self.checkAgentId(False)
                    confTime=time.time()
                if self.plugInit and self.pluStatus == 1 and self.getTaskRetry<=jkbConfig.getTaskRetry:
                    if time.time()>getTaskTime+jkbConfig.getTaskFailedInterval:
                        self.getUsrPluginSet()
                        self.doTask()
                        getTaskTime=time.time()
                if time.time()>postTime+self.postDataInterval:
                    self.doAction()
                    postTime=time.time()

                time.sleep(1)

            time.sleep(3)
        except Exception :
            jkbLib.error(traceback.format_exc())

    def checkAgentId(self,isF=False):
        host=jkbLib.getHostInfo()
        
        macIsCh=False
        if 'mac' in self.hostInfo and self.hostInfo['mac']!=host['mac']:
            macIsCh=True
            
        isdiff=self.checkHostDiff(host)
        self.hostInfo=host
        jkbVar.serStats['agentName']=str(host['hn'])+'-'+str(jkbConfig.agentPort)
        if jkbVar.agentId == '':
            return self.createAgentId(host)
        elif jkbConfig.isFixedAgentId:
            if not isdiff :
                return True
            parms = {'agentId':int(jkbVar.agentId),'agentName':jkbVar.serStats['agentName'],'hostName':host['hn'],'agentPort':int(jkbConfig.agentPort),
            'ipv4Address':host['ip'],'ipv6Address':host['ipv6'],'macAddress':host['mac'],'accountId':int(jkbVar.accountId)}
            
            ret=jkbLib.postRetry(jkbVar.agentUp,parms,10,3)
            if ret==False:
                jkbLib.error('agentId update failed!!Request failed.')
                return False
            if ret['status']!='success':
                jkbLib.error('agentId update failed!!')
                self.exit()
                return False
        else:
            if isF:
                parms = {'agentId':int(jkbVar.agentId),'agentPort':int(jkbConfig.agentPort),'ipv4Address':host['ip'],
                'ipv6Address':host['ipv6'],'macAddress':host['mac'],'accountId':int(jkbVar.accountId)}
                ret=jkbLib.postRetry(jkbVar.agentCheck,parms,10,3)
                if ret==False:
                    jkbLib.error('agentId check failed!!Request failed.')
                    self.exit()
                    return False
                if ret['status']!='success':
                    jkbLib.error('agentId check failed!!')
                    return self.createAgentId(host)
            
            if not isdiff :
                return True
            if macIsCh:
                jkbLib.error('mac is changed!!')
                return self.createAgentId(host)
                
            parms = {'agentId':int(jkbVar.agentId),'agentName':jkbVar.serStats['agentName'],'hostName':host['hn'],
            'agentPort':int(jkbConfig.agentPort),'ipv4Address':host['ip'],'ipv6Address':host['ipv6'],'macAddress':host['mac'],
            'accountId':int(jkbVar.accountId)}
            ret=jkbLib.postRetry(jkbVar.agentUp,parms,10,3)
            if ret==False:
                jkbLib.error('agentId update failed!!Request failed.')
                return False
            return True
                    
    def checkHostDiff(self,host):
        if self.hostInfo == {}:
            return True
        for key in host:
            if key=='runtime' or key=='freetime':
                continue
            if key in self.hostInfo and self.hostInfo[key] != host[key]:
                return True
        return False

    def createAgentId(self,host):
        jkbLib.info('create AgentId start')
        jkbVar.serStats['details']={}
        jkbVar.plugStats={'traceroute': {}, 'ping': {}, 'http': {}, 'tcp': {}}
        if self.objList != {}:
            for one in self.objList:
                self.objList[one].plugStop()
            self.objList = {}
        self.taskList = []
        f=open(self.homePath+'config/jkbVar.py','r')
        conf = f.read()
        f.close()
        self.hostInfo=host
        parms = {'agentName':jkbVar.serStats['agentName'],'hostName':host['hn'],'agentPort':int(jkbConfig.agentPort),'ipv4Address':host['ip'],
        'ipv6Address':host['ipv6'],'macAddress':host['mac'],'accountId':int(jkbVar.accountId),'userId':int(jkbVar.userId)}
        ret=jkbLib.postRetry(jkbVar.agentReg,parms,15,3)
        if ret==False or ret['status']!='success':
            jkbLib.error('agentId register failed!!')
            jkbLib.info('agentId register failed!!')
            self.exit()
            return False
        agentId=ret['agentId']
        monitorId=ret['monitorId']
        conf=re.sub('agentId = "([0-9]*)"','agentId = "'+str(agentId)+'"',conf)
        conf=re.sub('monitorId = "([0-9]*)"','monitorId = "'+str(monitorId)+'"',conf)
        f=open(self.homePath+'config/jkbVar.py','w')
        f.write(conf)
        f.close()
        reload(jkbVar)
        jkbVar.serStats['startedDate']=jkbLib.date(time.time()+jkbVar.serverTimeDiff, format = '%Y-%m-%d %H:%M:%S')
        jkbVar.serStats['status']='Running'
        jkbVar.serStats['details']={}
        jkbLib.info('create AgentId end. new agentId is '+str(agentId))
        
        self.getUsrPluginSet()
        self.doTask()
        return True
    
    def doAction(self):
        try:
            if self.pluStatus ==0 and self.objList!={}:
                for oneTask in self.objList:
                    self.objList[oneTask].plugStop()

                jkbVar.serStats['details']={}
                jkbVar.plugStats={'traceroute': {}, 'ping': {}, 'http': {}, 'tcp': {}}
                self.objList={}
                jkbVar.serStats['status']='Pause'
                return True
            if self.pluStatus == -1 :
                self.pluStatus=1
                self.getUsrPluginSet()
                self.doTask()
                jkbVar.serStats['status']='Running'
            if self.taskAction==[] or self.taskAction=="" or self.pluStatus != 1:
                self.taskAction=[]
                return True
            for one in self.taskAction:
                if one['action']=='Insert' or one['action']=='Resume':
                    if one['taskId'] not in self.objList:
                        parms={'agentId':int(jkbVar.agentId),'taskIds':[one['taskId']]}
                        vet=jkbLib.postRetry(jkbVar.configUrl,parms,5,3)
                        if vet['data']!=[] and vet != False:
                            self.addTaskObj(vet['data'])
                            self.startOne(self.taskList[0])
                            
                if one['action']=='Update':
                    if one['taskId'] in self.objList:
                        parms={'agentId':int(jkbVar.agentId),'taskIds':[one['taskId']]}
                        vet=jkbLib.postRetry(jkbVar.configUrl,parms,5,3)
                        if vet['data']!=[] and vet != False:
                            self.addTaskObj(vet['data'])
                            if self.objList[one['taskId']].taskConf['frequency'] != int(vet['data'][0]['frequency']):
                                self.stopOne(self.taskList[0])
                                self.startOne(self.taskList[0])
                            else:
                                self.objList[one['taskId']].setConf(self.taskList[0].getConf())
                    else:
                        parms={'agentId':int(jkbVar.agentId),'taskIds':[one['taskId']]}
                        vet=jkbLib.postRetry(jkbVar.configUrl,parms,5,3)
                        if vet['data']!=[] and vet != False:
                            self.addTaskObj(vet['data'])
                            self.startOne(self.taskList[0])
                            
                if one['action']=='Delete' or one['action']=='Pause':
                    if one['taskId'] in self.objList:
                        self.objList[one['taskId']].plugStop()
                        del self.objList[one['taskId']]
                        taskType=jkbVar.serStats['details'][one['taskId']]['taskType']
                        if taskType in jkbVar.plugStats and one['taskId'] in jkbVar.plugStats[taskType]:
                            del jkbVar.plugStats[taskType][one['taskId']]
                        if one['taskId'] in jkbVar.serStats['details']:
                            del jkbVar.serStats['details'][one['taskId']]
                    
        except Exception :
            jkbLib.error(traceback.format_exc())
        self.taskAction=[]
        
    def doTask(self):
        if self.plugInit:
            if self.getTaskRetry>jkbConfig.getTaskRetry:
                jkbLib.info('采集器获取任务失败')
            else:
                jkbLib.info('采集器获取任务失败，准备重试')
            return False
        if self.taskList == []:
            jkbLib.info('采集器还没有采集任务')
            return False
        try:
            for one in self.taskList:
                if one.taskId in self.objList:
                    self.objList[one.taskId].setConf(one.getConf())
                if one.status == 1 and one.taskId not in self.objList:
                    self.startOne(one)
                if one.status == 0 and one.taskId in self.objList:
                    self.stopOne(one)
        except Exception :
            jkbLib.error(traceback.format_exc())

    
    def addTaskObj(self,arr):
        self.taskList=[]
        if arr==[]:
            return True
        for one in arr:
            if one['taskType']=='http':
                h = plugTask.HttpTask()
            elif one['taskType']=='ping':
                h = plugTask.PingTask()
            elif one['taskType']=='tcp':
                h = plugTask.TcpTask()
            elif one['taskType']=='traceroute':
                h = plugTask.TracerouteTask()
            else:
                continue
            h.taskId = one['taskId']
            h.taskName = one['taskName']
            h.frequency = one['frequency']
            h.retry = one['retry']
            h.moduloValue = one['moduloValue']
            if 'pic_st' in one:
                h.pic_st = one['pic_st']
            if 'pic_end' in one:
                h.pic_end = one['pic_end']
            #if one['checkStartTime'] > 0:
                #h.checkStartTime = jkbLib.strtotime(one['checkStartTime'],'%Y-%m-%d %H:%M:%S')
            for key in one['customSettings']:
                if hasattr(h,key):
                    h.setParms(key,one['customSettings'][key])
            self.taskList.append(h)
            
    
    def startOne(self,plug):
        try:
            time.sleep(0.02)
            if 'details' not in jkbVar.serStats:
                jkbVar.serStats['details']={}
            jkbVar.serStats['details'][plug.taskId]=plug.getConf()
            module_meta = __import__('plugin', globals(), locals(), [str(plug.pluginFileName)]) 
            class_meta = getattr(module_meta, plug.pluginFileName)
            c = getattr(class_meta, plug.pluginFileName)
            obj = c(plug.taskId,plug.getConf(),plug.taskType)
            self.objList[plug.taskId]=obj
            obj.setIntervalTime(plug.frequency)
            obj.setName(plug.pluginFileName+str(plug.taskId))
            obj.setDaemon(True)
            obj.start()
            
        except Exception :
            jkbLib.error(traceback.format_exc())
        

    def stopOne(self,plug):
        try:
            self.objList[plug.taskId].plugStop()
            del self.objList[plug.taskId]
            del jkbVar.serStats['details'][plug.taskId]
            del jkbVar.plugStats[plug.taskType][plug.taskId]
        except Exception :
            jkbLib.error(traceback.format_exc())

        

    def restart(self):
        jkbLib.rmPid('agent')
        os._exit(0)
       
    def getUsrPluginSet(self):
        parms = {'agentId':int(jkbVar.agentId),'taskIds':[]}
        vat = jkbLib.post(jkbVar.configUrl,parms)
        if vat==False:
            self.plugInit = True
            self.getTaskRetry+=1
            jkbLib.error('调用任务配置信息接口失败，考虑网络不通！')
            return False
        self.plugInit = False
        self.getTaskRetry = 0
        vat['data']=self.cutTaskPic(vat['data'])
        self.addTaskObj(vat['data'])
        return True
        
    def cutTaskPic(self,tasks):
        curNum=0
        curPic=1
        for one in range(len(tasks)):
            if curNum >=jkbConfig.taskPicNum:
                curNum=0
                curPic+=1
            curNum+=1
            tasks[one]['pic_st']=(curPic-1)*jkbConfig.taskPicTime
            tasks[one]['pic_end']=curPic*jkbConfig.taskPicTime
        return  tasks



class PostPro(threading.Thread):
    def __init__(self,agentProcess):
        self.agentProcess=agentProcess
        threading.Thread.__init__( self )
        self.postDataInterval=3
        
    def run(self):
        postTime=time.time()
        while True: 
            if time.time()>postTime+self.postDataInterval:
                postTime=time.time()
                self.postData()
            time.sleep(1)
            
                
    def postData(self):
        try:
            reData=[]
            NoData=True
            for taskId in self.agentProcess.objList:
                obj = self.agentProcess.objList[taskId]
                tmp = obj.returnData()
                if tmp!={}:
                    tmp['pushTime']=jkbLib.date(time.time()+jkbVar.serverTimeDiff, format = '%Y-%m-%d %H:%M:%S')
                    self.agentProcess.objList[taskId].taskConf['pushTime']=tmp['pushTime']
                    reData.append(tmp)
                    NoData=False
                obj.clearData()
            if NoData:
                return {}

            postRe=0
            while True:
                st=time.time()
                vet=jkbLib.post(jkbVar.postUrl,reData,15)
                if vet == False:
                    if postRe<=jkbConfig.postDataRetry:
                        postRe+=1
                        if postRe>jkbConfig.postDataRetry:
                            jkbLib.error('上报数据失败')
                            break;
                        jkbLib.error('上报数据失败，正在重试')
                        time.sleep(jkbConfig.postDataFailedInterval)
                        continue
                    else:
                        break;
                else:
                    if time.time()-st > jkbConfig.ReportTime:
                        jkbLib.info('数据上报时间很慢，考虑网络原因，耗时:'+str(time.time()-st))
                    break;
        except Exception :
            jkbLib.error(traceback.format_exc())

class MasterProcessMonitor(threading.Thread):

    def __init__(self, agentProcess):
        self.agentProcess = agentProcess
        self.lock = threading.Lock()
        self.lastHeartbeat = time.time()
        self.running = True
        threading.Thread.__init__(self)

    def run( self ):
        while self.running:
            time.sleep(4)
            try:
                try:
                    self.lock.acquire()

                    if (time.time()-self.lastHeartbeat) > 12:
                        self.agentProcess.stop()
                        jkbLib.rmPid('agent')    
                        os._exit(0)

                finally:
                    self.lock.release()

            except Exception :
                jkbLib.error(traceback.format_exc())
                raise

    def stop( self ):
        self.running = False

    def heartbeat(self):
        try:
            self.lock.acquire()
            self.lastHeartbeat = time.time()
        finally:
            self.lock.release()

class MyServer(threading.Thread):
    def __init__(self):
        threading.Thread.__init__( self )
    def run(self):
        ip=jkbLib.get_ip()
        jkbLib.info('Server start '+ip+':'+str(jkbConfig.agentPort))
        ser = HTTPServer(('', int(jkbConfig.agentPort)), myServHandler)
        ser.serve_forever()
    
class myServHandler(BaseHTTPRequestHandler):
    def log_request(self,code):
        pass
    def log_error(self,code,e):
        pass
    def do_GET(self):
        if self.path=='/stats':
            self.send_response(200)
            self.send_header('content-type', 'text/html')
            self.end_headers()
            stats=jkbVar.serStats
            stats['agentId']=jkbVar.agentId
            stats['stats']={'http':{'goodTasks':0,'failedTasks':0},'ping':{'goodTasks':0,'failedTasks':0},
            'tcp':{'goodTasks':0,'failedTasks':0},'traceroute':{'goodTasks':0,'failedTasks':0}}

            for one in jkbVar.plugStats['http']:
                if jkbVar.plugStats['http'][one] == 1:
                    stats['stats']['http']['goodTasks']+=1
                else:
                    stats['stats']['http']['failedTasks']+=1
            for one in jkbVar.plugStats['ping']:
                if jkbVar.plugStats['ping'][one] == 1:
                    stats['stats']['ping']['goodTasks']+=1
                else:
                    stats['stats']['tcp']['failedTasks']+=1
            for one in jkbVar.plugStats['tcp']:
                if jkbVar.plugStats['tcp'][one] == 1:
                    stats['stats']['tcp']['goodTasks']+=1
                else:
                    stats['stats']['tcp']['failedTasks']+=1
            for one in jkbVar.plugStats['traceroute']:
                if jkbVar.plugStats['traceroute'][one] == 1:
                    stats['stats']['traceroute']['goodTasks']+=1
                else:
                    stats['stats']['traceroute']['failedTasks']+=1
            try:
                self.wfile.write(json.dumps(stats).encode('utf-8','ignore'))
            except Exception :
                stats['agentName']=stats['agentName'].decode('gbk')
                self.wfile.write(json.dumps(stats).encode('utf-8','ignore'))
        else:
            self.send_response(200)
            self.send_header('content-type', 'text/html')
            self.end_headers()
            self.wfile.write('url error'.encode('utf-8'))
            
            
class CommendPro(threading.Thread):
    def __init__(self,agentProcess):
        self.agentProcess=agentProcess
        threading.Thread.__init__( self )
    def run(self):
        time.sleep(8)
        while True:
            if jkbVar.agentId=='':
                time.sleep(3)
                continue
                
            self.heartDo()
            #请求服务器命令
            #self.serCmd()
            time.sleep(30)
            
    def heartDo(self):
        try:
            #进行服务器心跳
            parms={'agentId':int(jkbVar.agentId),'agentStatus':jkbVar.serStats['status']}
            vet=jkbLib.post(jkbVar.heartbeat+str(jkbVar.agentId),parms,5)
            #vet=jkbLib.get(jkbVar.heartbeat+str(jkbVar.agentId)+'?agentStatus='+jkbVar.serStats['status'],3)
            jkbLib.sysinfo(vet)
            if vet!=False:
                if 'serverTime' in vet:
                    arr=vet['serverTime'].split('.')
                    servTime = jkbLib.strtotime(arr[0],'%Y-%m-%d %H:%M:%S')+float('0.'+arr[1])
                    jkbVar.serverTimeDiff=servTime-time.time()
                if vet['data']!=[]:
                    self.agentProcess.taskAction=vet['data']
                if 'agentStatus' in vet and vet['agentStatus']=='Running' and self.agentProcess.pluStatus==0:
                    self.agentProcess.pluStatus=-1
                if 'agentStatus' in vet and vet['agentStatus']=='Pause' and self.agentProcess.pluStatus==1:
                    self.agentProcess.pluStatus=0
                if 'agentStatus' in vet and vet['agentStatus']=='Delete':
                    self.agentProcess.exit()
        except Exception :
            jkbLib.error(traceback.format_exc())
            
    def serCmd(self):
        try:
            ret=jkbLib.get(jkbVar.cmdGet+str(jkbVar.agentId),15)
            if ret!=False and ret['data']!={} and ret['status']!='failed':
                parms={'instructId':ret['data']['instructId'],'agentId':int(jkbVar.agentId),'result':'successs'}
                jkbLib.post(jkbVar.cmdDone,parms)
                jkbLib.sysinfo(ret)
                if ret['data']['action']=='Reboot':
                    jkbLib.info('Reboot agent!')
                    self.agentProcess.restart()
                if ret['data']['action']=='Pause':
                    jkbLib.info('Pause agent!')
                    self.agentProcess.pluStatus=0
                if ret['data']['action']=='Resume':
                    jkbLib.info('Resume agent!')
                    self.agentProcess.pluStatus=-1
                if ret['data']['action']=='Stop':
                    jkbLib.info('Exit agent!')
                    self.agentProcess.exit()
        except Exception :
            jkbLib.error(traceback.format_exc())
        
        
class MasterPingReader(threading.Thread):

    def __init__(self, agentProcess, masterMonitor):
        self.agentProcess = agentProcess
        self.masterMonitor = masterMonitor
        threading.Thread.__init__( self )
       

    def run(self):
        while True:
            time.sleep(3)
            try:
                line = sys.stdin.readline()
                if not line:
                    continue

                if line == 'stop\n':
                    try:
                        jkbLib.rmPid('agent')
                        self.agentProcess.stop()
                        self.masterMonitor.stop()
                    finally:
                        os._exit(0)
                
                if line == 'restart\n':
                    self.agentProcess.restart()
                    
                if line == 'ping\n':
                    self.masterMonitor.heartbeat()
                    continue

            except Exception :
                jkbLib.error(traceback.format_exc())


if __name__ == "__main__":
    agentPid = os.getpid()

    jkbLib.writePid(agentPid,'agent')
    
    jkbLib.info( 'Starting agent process' )
    jkbLib.printout('Starting agent process')
    parentPid = None
    startType = None
    try:
        if len(sys.argv) > 1:
            parentPid = sys.argv[1]
            startType = sys.argv[2]
    except Exception :
        jkbLib.error(traceback.format_exc())

    try:
        ms = MyServer()
        ms.setName('AgentServer')
        ms.start()
        
        agentProcess = AgentProcess(startType)
        agentProcess.setName('AgentProcess')
        agentProcess.start()
        
        comm=CommendPro(agentProcess)
        comm.setName('CommProcess')
        comm.start()
        
        p={}
        for i in range(jkbConfig.postProNum):
            p[i]=PostPro(agentProcess)
            p[i].setName('postProcess_'+str(i))
            p[i].start()
        
        monitor = MasterProcessMonitor(agentProcess)
        monitor.setName('MasterProcessMonitor')
        monitor.start()

        pingReader = MasterPingReader(agentProcess, monitor)
        pingReader.setName('MasterPingReader')
        pingReader.start()

        jkbLib.info('Started agent process, parent PID:' +str(parentPid)+' the agent PID:'+str(agentPid))
        jkbLib.printout('Started agent process, parent PID:' +str(parentPid)+' the agent PID:'+str(agentPid))
        if startType == 'service':
            jkbLib.info('Starting service JKBNewAgentService-'+str(jkbConfig.agentPort))
    except Exception :
        jkbLib.error(traceback.format_exc())

