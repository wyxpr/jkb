# -*- coding: utf-8 -*-
"""
 Copyright © 2012 云智慧（北京）科技有限公司 <http://www.jiankongbao.com/>
 
 Permission is hereby granted, free of charge, to any person obtaining a copy of this software
 and associated documentation files (the "Software"), to deal in the Software without restriction,
 including without limitation the rights to use, copy, modify, merge, publish, distribute,
 sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:
 
 The above copyright notice and this permission notice shall be included in all copies or
 substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND 
 NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, 
 DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE. 
"""
"""
Jiankongbao  plugin class
sevn.huo@yunzhihui.com
"""

class plugTask():
    def __init__(self):
        self.taskId=0
        self.frequency=60*2
        self.status=1
        self.scheduleTime=0
        self.collectTime=0
        self.pushTime=0
        self.checkStartTime=0
        self.taskName=''
        self.retry=0
        self.moduloValue=''
        self.pic_st=0
        self.pic_end=5
        
        
    def setParms(self,key,val):
        setattr(self,key,val)
    def getConf(self):
        return self.__dict__

        

class HttpTask(plugTask):

    def __init__(self):

        self.url = ''
        self.httpUser = ''
        self.httpPwd = ''
        self.param = ''
        self.ip = ''
        self.header = ''
        self.cookies = ''
        self.patternType = '0'
        self.patternStr = ''
        self.submitMethod = '0'
        self.patternTarget = '0'
        self.redirect = '0'
        self.redirectTimes = '3'
        
        
        self.taskType='http'
        self.pluginFileName='HttpPlugin'
        plugTask.__init__(self)
        
class PingTask(plugTask):

    def __init__(self):

        self.host = ''
        
        self.taskType='ping'
        self.pluginFileName='PingPlugin'
        plugTask.__init__(self)
             
        
class TcpTask(plugTask):

    def __init__(self):

        self.host = ''
        self.tcpPort=''
        
        self.taskType='tcp'
        self.pluginFileName='TcpPlugin'
        plugTask.__init__(self)
             
        
class TracerouteTask(plugTask):

    def __init__(self):

        self.host = ''
        
        self.taskType='traceroute'
        self.pluginFileName='TracePlugin'
        plugTask.__init__(self)
