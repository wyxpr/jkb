# -*- coding: utf-8 -*-
"""
 Copyright © 2012 云智慧（北京）科技有限公司 <http://www.jiankongbao.com/>
 
 Permission is hereby granted, free of charge, to any person obtaining a copy of this software
 and associated documentation files (the "Software"), to deal in the Software without restriction,
 including without limitation the rights to use, copy, modify, merge, publish, distribute,
 sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:
 
 The above copyright notice and this permission notice shall be included in all copies or
 substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND 
 NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, 
 DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE. 
"""
"""
Jiankongbao  plugin class
sevn.huo@yunzhihui.com
"""

import random
import time
from lib import jkbLib
import threading

from config import jkbVar
from config import jkbConfig

try:
    import urllib2
except ImportError:
    import urllib.request as urllib2
try:
    from  urllib import parse
except ImportError:
    import urllib as parse

try:
    import json
except ImportError:
    import simplejson as json
    
try:
    import zlib
except ImportError:
    zlib=''
    
try:
    import base64
except ImportError:
    base64=''
    
import traceback

import re


class plugin(threading.Thread):

    def __init__(self,taskId,taskConf,taskType):
        self.taskId = taskId
        self.taskConf = taskConf
        self.taskConf_tmp = taskConf
        self.taskType = taskType
        self.logHead = 'task_name:'+self.taskConf['taskName']+' id:'+str(taskId)+'  type:'+taskType+'  error:'
        self.code = 'A001'
        self.error_info = ''
        self.error_time = 0
        self.lock = threading.Lock()
        self.running=True
        self.interval=120
        self.DataList={}
        threading.Thread.__init__(self)

    def run(self):
        self.taskConf = self.taskConf_tmp

        time.sleep(random.uniform(self.taskConf['pic_st'],self.taskConf['pic_end']))
        prev_time=0
        while self.running:
            cur_time = time.time()
            if prev_time>0:
                cur_time+=self.interval*60-(cur_time-prev_time)
                prev_time=cur_time
            else:
                prev_time=cur_time
            self.taskConf = self.taskConf_tmp
            if 'frequency' in self.taskConf:
                self.interval=self.taskConf['frequency']
            self.taskConf['scheduleTime']=jkbLib.date(self.getCurTime(), format = '%Y-%m-%d %H:%M:%S')
            if jkbConfig.debug:
                jkbLib.debug('task('+str(self.taskId)+':'+self.taskConf['taskName']+') get data start')
            self.getData()
            if jkbConfig.debug:
                jkbLib.debug('task('+str(self.taskId)+':'+self.taskConf['taskName']+') get data end')
            if((time.time() - cur_time) < self.interval*60) :
                time.sleep(self.interval*60 - (time.time() - cur_time))
            else :
                prev_time=0
                jkbLib.error('get data out time!!')
                time.sleep(30)
           
            
    def setIntervalTime(self,int_time):
        try:
            self.lock.acquire()
            self.interval=int_time
        finally:
            self.lock.release()
            
    def setData(self,data):
        try:
            self.taskConf['collectTime']=jkbLib.date(self.getCurTime(), format = '%Y-%m-%d %H:%M:%S')
            self.lock.acquire()
            if data==False:
                data={}
            data['agentId']=int(jkbVar.agentId)
            data['accountId']=int(jkbVar.accountId)
            data['userId']=int(jkbVar.userId)
            data['taskId']=self.taskId
            data['monitorId']=int(jkbVar.monitorId)
            data['taskType']=self.taskType
            data['frequency']=self.taskConf['frequency']
            data['moduloValue']=self.taskConf['moduloValue']
            data['scheduleTime']=self.taskConf['scheduleTime']
            data['collectTime']=self.taskConf['collectTime']
            data['pushTime']=self.taskConf['pushTime']
            data['error_info']=self.error_info
            jkbVar.serStats['details'][self.taskId]=self.taskConf
            jkbVar.serStats['details'][self.taskId]['lastRunDate'] = jkbLib.date(self.getCurTime(), format = '%Y-%m-%d %H:%M:%S')
            if self.code == 'A001':
                jkbVar.serStats['details'][self.taskId]['lastRunStatus']='Successful'
                jkbVar.plugStats[self.taskType][self.taskId] = 1
            else:
                jkbVar.serStats['details'][self.taskId]['lastRunStatus']=self.error_info
                jkbVar.plugStats[self.taskType][self.taskId] = 0
            
            self.DataList=data
        finally:
            self.lock.release()            
            
    def close_proc(self,cur_proc):
        if cur_proc.poll() is None:
            try:
                if cur_proc.stdin:
                    cur_proc.stdin.close()
                if child.stdout:
                    cur_proc.stdout.close()
                if cur_proc.stderr:
                    cur_proc.stderr.close()
                cur_proc.terminate()
            except:
                try:
                    cur_proc.kill()
                except:
                    pass
        else:
            try:
                cur_proc.kill()
            except:
                pass
    
    def setConf(self, conf):
        try:
            self.lock.acquire()
            self.taskConf_tmp = conf
        finally:
            self.lock.release()
            

    def getCurTime(self):
        return int(time.time()+jkbVar.serverTimeDiff)


    def returnData(self):
        try:
            self.lock.acquire()
            return self.DataList
        finally:
            self.lock.release()
    
    def clearData(self):
        try:
            self.lock.acquire()
            self.DataList={}
        finally:
            self.lock.release()

    def plugStop(self):
        try:
            self.lock.acquire()
            self.running=False
        finally:
            self.lock.release()
        

    def plugStart(self):
        try:
            self.lock.acquire()
            self.running=True
        finally:
            self.lock.release()
    
    def errorInfoDone(self, info):
        try:
            self.lock.acquire()
            rem = re.compile(r'(.*)\n',re.M)
            matches = rem.findall(info)
            lens=len(matches)
            self.error_time+=1
            if lens>1:
                self.error_info = matches[0]+matches[1]+'  '+matches[lens-1]
            else :
                self.error_info = info
            self.code='A002'
            #if self.error_time>10:
                #self.code='A003'
        finally:
            self.lock.release()

    def intStatus(self):
        self.code = 'A001'
        self.error_time = 0
        self.error_info = ''

